package Client.Startup;

import Client.View.ClientInterpreter;

import java.io.IOException;

public class ClientStarter {
    public static void main (String[] args) throws IOException {

        ClientInterpreter clientInterpreter = new ClientInterpreter();
        clientInterpreter.start();


    }
}
