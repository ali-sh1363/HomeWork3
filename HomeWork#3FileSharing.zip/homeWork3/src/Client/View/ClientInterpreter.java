package Client.View;

import Common.FileServer;
import Common.UserFile;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

public class ClientInterpreter implements Runnable {
    private FileServer fileServer;
    private boolean receivingCmds = false;
    private final ThreadSafety threadSafety = new ThreadSafety();
    private BufferedReader bufferedReader;
    private boolean connected =false;
    private final UserFile userFile;
    private long myID;
    private static final String PROMPT = ">>> ";
    private boolean success = false;


    public ClientInterpreter() throws RemoteException {
        userFile = new ConsoleOutPut();

    }

    public void start() {
        if (receivingCmds) {
            return;
        }
        receivingCmds = true;
        new Thread(this).start();
    }


    @Override
    public void run() {
                receivingCmds = true;
                try {
                    fileServer = (FileServer) Naming.lookup("//" + FileServer.HOST + "/" + FileServer.SERVER_NAME_IN_REGISTRY);
                } catch (MalformedURLException | NotBoundException | RemoteException e) {
                    e.printStackTrace();
                }
                intro();
                BufferedReader  bufferedReader = new BufferedReader(new InputStreamReader(System.in));
                String command;
                String [] array;
                while (receivingCmds){
                    try {
                        threadSafety.print(PROMPT);
                        command = bufferedReader.readLine();
                        command = command.trim();
                        array=command.split(" ");
                        array[0]=array[0].toLowerCase();


                    ///////////////login
                        if(array[0].equalsIgnoreCase("login")&& array.length==3 ){
                            if(!connected){
                               myID =fileServer.login(userFile,array[1],array[2]);
                                if(myID==-1){                                //i can use switch case but is not possible do to the long type
                                    threadSafety.println("User Name or Password in Wrong \n");
                                }else if(myID == 0){
                                    threadSafety.println("you are already logged in \n");

                                }else {
                                    threadSafety.println("welcome back");
                                    connected =true;
                                }
                            }else {
                                threadSafety.println("nothing \n");
                            }
                        }

                    /////////////////logOut
                        else if(array[0].equalsIgnoreCase("logout")&& array.length==1){
                            success = fileServer.logout(myID);
                            if(success){
                                threadSafety.println("You have been Log Out Successfully \n");
                                connected =false;
                            }else {
                                threadSafety.println("First you need to login !!! \n");
                            }
                        }

                    /////////////////Register
                        else if(array[0].equalsIgnoreCase("register")&& array.length==3){
                            success=fileServer.register(array[1],array[2]);
                            if(success){
                                threadSafety.println("You are Registered Successfully \n");
                            }else {
                                threadSafety.println("Please Select Another UserName \n");
                            }
                        }

                    ////////////////Unregister
                        else if(array[0].equalsIgnoreCase("unregister")&& array.length==3){
                            success = fileServer.unregister(array[1],array[2]);
                            if(success){
                                threadSafety.println("You are Unregistered Successfully \n");
                            }else {
                                threadSafety.println("Your UserName or Password is Wrong \n");
                            }
                        }
                        
                    //////////////Help
                        else if(array[0].equalsIgnoreCase("help")&& array.length==1){
                            Help();
                        }
                        
                    /////////////EXIT
                        else if(array[0].equalsIgnoreCase("exit")&& array.length==1){
                         //   if(connected){                                // by this method just useres who login the system can exit
                               fileServer.logout(myID);
                                connected =false;
                            receivingCmds = false;
                             threadSafety.println("Exit Successfully !!! \n");
//                            }else {
//                                threadSafety.println("Press Help \n");
//                            }                             
                        }
                        
                    //////////////List
                        else if(array[0].equalsIgnoreCase("list") && array.length == 1){
                            if(connected){
                                List<String> fileList = new ArrayList<String>();
                                fileList = fileServer.fileList(myID);
                                threadSafety.println("");
                                for (String s: fileList){
                                    threadSafety.println(s);
                                }
                                threadSafety.println("");
                            }
                            else{
                                threadSafety.println("First you need to login  !!!\n");
                            }
                        }
                        
                    /////////////ReadFile
                        else if(array[0].equalsIgnoreCase("read") && array.length == 2){
                            if(connected){
                                String fileName = array[1];

                                String[] content = fileServer.readFile(fileName, myID);

                                if(content == null){
                                    threadSafety.println("Your dont have an access to the file or The file doesn't exist.\n");
                                }
                                else{
                                    threadSafety.println("\n");
                                    threadSafety.println("---------------------------------------------Start of File------------------------------------------");
                                    threadSafety.println("\n");
                                    for (String content1 : content) {
                                        threadSafety.println(content1);
                                    }
                                    threadSafety.println("\n");
                                    threadSafety.println("----------------------------------------------End of File-------------------------------------------");
                                    threadSafety.println("\n");
                                }
                            }
                            else{
                                threadSafety.println("First you need to login  !!!\n");
                            }
                        }
                        
                    //////////////WriteFile
                        else if(array[0].equalsIgnoreCase("write") && array.length == 3){
                            if(connected){
                                String fineNameInServer = array[1];
                                String method = array[2];                //overwritten or appended

                                threadSafety.println("Write :\n");
                                String dataToWrite = bufferedReader.readLine();

                                success = fileServer.writeFile(fineNameInServer, dataToWrite, myID, method);

                                if (success){
                                    threadSafety.println("Successful Write!!!\n");
                                }
                                else{
                                    threadSafety.println("Your dont have an access to the file or The file doesn't exist.\n");
                                }
                            }
                            else{
                                threadSafety.println("First you need to login  !!!\n");
                            }
                        }
                        
                    /////////////Notification 
                        else if(array[0].equalsIgnoreCase("notify") && array.length == 2){
                            if(connected){
                                String fileName = array[1];

                                success = fileServer.notification(fileName, myID);

                                if (success){
                                    threadSafety.println("Successful Notify!!!\n");
                                }
                                else{
                                    threadSafety.println("Your are not  file owner or file is private\n");
                                }
                            }
                            else{
                                threadSafety.println("First you need to login  !!!\n");
                            }
                        }
                        
                    /////////////Download
                        
                         else if(array[0].equalsIgnoreCase("download") && (array.length == 2 || array.length == 3)){
                            if(connected){
                                String fileName = array[1];
                                String filePath;
                                if(array.length == 2){
                                    filePath = "downloaded path\\";
                                    filePath += fileName;
                                }
                                else{
                                    filePath = array[2];
                                    if(filePath.endsWith("\\")){
                                        filePath += fileName;
                                    }
                                    else{
                                        filePath = filePath + "\\" + fileName;
                                    }
                                }
                                String[] content = fileServer.downloadFile(fileName, myID);
                                if(content == null){
                                    threadSafety.println("Your dont have an access to the file or The file doesn't exist.\n");
                                }
                                else{
                                    success = saveFile(filePath, content);
                                    if(success){
                                        threadSafety.println("Successful Download!!!\n");
                                    }
                                    else{
                                        threadSafety.println("ClientError: Check your FILE_PATH)\n");
                                    }
                                }
                                    }
                                    else{
                                threadSafety.println("First you need to login  !!!\n");
                            }
                        }
                        
                    /////////////uploadFile
                          else if(array[0].equalsIgnoreCase("upload") && ( 2 < array.length && array.length < 6)){
                    if(connected){
                        String fileAddress = array[1];
                        String fileNameInServer = array[2];
                        String[] content = loadFile(fileAddress);
                        boolean flag = false;
                        boolean pubAccess = false;
                        boolean rwPermission = false;
                        if(array.length > 3){
                            if(array[3].equalsIgnoreCase("PUBLIC ACCESS")){
                                pubAccess = true;
                                if((array.length == 5) && array[4].equalsIgnoreCase("READ & WRITE PERMISION")){
                                    rwPermission = true;
                                }
                                else{
                                    flag =true;
                                }
                            }
                            else{
                                flag = true;
                            }
                        }
                        if(content[0].equalsIgnoreCase("empty")){
                            threadSafety.println("Problem with your FILE_PATH!!!\n");
                        }
                        else if(flag){
                            threadSafety.println("Problem with your Public Access or Write Permission setting!!!\n");
                        }
                        else{
                            success = fileServer.uploadFile(fileNameInServer, content, myID, pubAccess, rwPermission);
                            if (success){
                                threadSafety.println("Successful Upload!!!\n");
                            }
                            else{
                                threadSafety.println("Your upload was Unsuccesfull\n"+" the name chosen for you file in the server, already exists \n");
                            }
                        }
                    }
                    else{
                        threadSafety.println("First you need to login  !!!\n");
                    }
                }


                    }catch (IOException e){
                        System.out.println( "errrrrrrrro in ClientInterPreter" + e.getMessage());
                    }

                }
        }

    private void intro(){
     String introMessage = "\n========================================================================================\n"+
                            "                            Welcome to the program\n"+
                            "                    This is an Application for File Sharing\n"+
                            "                  If you Need More Information Please Type 'HELP'\n"+
                            "========================================================================================\n";

//        String s= "Well cpme toooooo";
//        threadSafety.println(s);
        threadSafety.println(introMessage);
    }

    private void  Help(){
        String helpMessage = "\n========================================================================================\n" +

                "1) REGISTER          --> register <username> <password>\n" +
                "2) UNREGISTER        --> unregister <username> <password>\n" +
                "3) LOGIN             --> login  <username> <password>\n" +
                "4) LOGOUT            --> logout\n" +
                "5) READ              --> read <filename>\n" +
                "6) Write             --> write <file name>\n" +
                "7) DELETE            --> delete <file name>\n" +
                "8) LIST              --> \n" +
                "9) UPLOAD            --> upload <file directiry> <file name> <public access> <write permission>\n" +
                "10) DOWNLOAD         --> download <file name> <file directory>\n" +
                "11) NOTIFICATION     --> notify <file name>\n" +
                "12) HELP             --> help \n" +
                "13) EXIT             --> exit\n" +
                "\n" +
                "========================================================================================\n";
          threadSafety.println(helpMessage);
     //   return helpMessage;
    }
    
    public boolean saveFile(String path, String content[]){
        try{
            File file = new File(path);
            try (PrintWriter toFile = new PrintWriter(new FileWriter(file))) {
                for (String content1 : content) {
                    toFile.println(content1);
                }
            }
            return true;
        }catch (IOException e){
            System.out.println("clientInterpreter SaveFile "+ e.getMessage());
            return false;
        }
    }
    
    public String[] loadFile(String fileAddress){
        try{
            boolean readOK = true;
            String[] content;
            try (BufferedReader fromFile = new BufferedReader(new FileReader(fileAddress))) {
                String paragraph = fromFile.readLine();
                String temp;
                while(readOK){
                    if((temp = fromFile.readLine()) == null)
                        readOK = false;
                    else{
                        paragraph = paragraph + "\n" + temp;
                    }
                }   content = paragraph.split("\n");
            }
            return content;
        }catch (IOException e){
            System.out.println("clientInterpreter LOadFile !!!"+e.getMessage());
            String problem = "empty";
            String[] res = problem.split(" ");
            return res;
        }
    }
}