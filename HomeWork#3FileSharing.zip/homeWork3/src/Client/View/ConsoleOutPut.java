package Client.View;

import Common.UserFile;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class ConsoleOutPut extends UnicastRemoteObject implements UserFile {

        private final ThreadSafety threadSafety = new ThreadSafety();

        public ConsoleOutPut() throws RemoteException {
        }

        @Override
    public void receivedMessage(String msg) {threadSafety.println(msg);
    }

}
