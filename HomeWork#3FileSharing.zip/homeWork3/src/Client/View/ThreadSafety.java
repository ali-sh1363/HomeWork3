package Client.View;

public class ThreadSafety {
    synchronized void print(String output) {
        System.out.print(output);
    }
    synchronized void println(String output) {
        System.out.print(output);
    }
}
