package Common;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

public interface FileServer extends Remote {



    public static final String SERVER_NAME_IN_REGISTRY = "FileServer";
    public static final String HOST = "localhost:1099";      //port for Registry


    long login(UserFile user, String userName , String passWord ) throws RemoteException;

    boolean logout(long id) throws RemoteException;

    boolean register(String username, String password)throws RemoteException;

    boolean unregister(String username, String password)throws RemoteException;

    List <String> fileList(long id)throws RemoteException;
    
    String[] readFile (String fileName, long userId) throws RemoteException;

    boolean writeFile(String fineNameInServer, String dataToWrite, long userId, String method) throws RemoteException;
    
    boolean notification(String fileName, long userId)throws RemoteException;
    
    String[] downloadFile(String fileName, long userId) throws RemoteException;
    
    boolean uploadFile(String fileName, String[] content, long userId, boolean pubAccess, boolean rwPermission) throws RemoteException;

}
