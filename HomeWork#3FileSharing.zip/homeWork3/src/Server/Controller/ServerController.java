package Server.Controller;

import Common.FileServer;
import Common.UserFile;
import Server.Integration.FileDAO;
import Server.Integration.UserDAO;
import Server.Model.FileInfo;
import Server.Model.UserInfo;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ServerController extends UnicastRemoteObject implements FileServer {
    private long userId = 0;
    private final List <UserInfo> userInfoList;
    private boolean success =false;
    private UserInfo userinfo;
    private UserInfo userInfo;
    private final UserDAO userdao;
    private final FileDAO filedao;


    public ServerController() throws RemoteException, ClassNotFoundException, SQLException{
        userInfoList = new CopyOnWriteArrayList<>();
        userdao = new UserDAO();
        filedao = new FileDAO();

    }
    @Override
    public synchronized long login(UserFile user, String userName, String passWord) throws RemoteException {
        UserInfo userInfoo = new UserInfo(user,userName,passWord);
         userId =userdao.loginToDatabase(user, userName, passWord);
         for (UserInfo element : userInfoList){
             if(element.userId == userId && element.connected){
                return 0;
            }
         }     
              if (userId > 9){
            userInfoo.connected = true;
            userInfoo.userId = userId;
            userInfoList.add(userInfoo);
        }
        return userId;
         }
        

    @Override
    public synchronized boolean logout(long id) throws RemoteException {
         for (UserInfo element : userInfoList) {
            if(element.userId == id && element.connected){
                element.connected = false;
                userInfoList.remove(element);
                success = true;
                if (userInfoList.isEmpty()){
                    break;
                }
            }
        }
        if (success){
            success = false;
            return true;
        }
        
        
        return false;
    }

    @Override
    public synchronized boolean register(String username, String password) throws RemoteException {
        success = userdao.registerToTable(username, password);
        return success;
    }

    @Override
    public synchronized boolean unregister(String username, String password) throws RemoteException {
        success = userdao.unregisterFromTablee(username, password);
        return success;
    }

    @Override
    public synchronized List<String> fileList(long userID) throws RemoteException {
        List <String> listOfFiles = new ArrayList<>();
        listOfFiles = filedao.fileList(userID);
        return listOfFiles;
    }

    @Override
    public synchronized String[] readFile(String fileName, long userId) throws RemoteException {
        
        FileInfo fileInfo = new FileInfo();
        String uid = Long.toString(userId);
        boolean permission = filedao.getFileFromDatabase(fileName, uid);
        if (permission){
            String[] content = fileInfo.downloadFile(fileName);
            String ownerId = filedao.ownerNotification(fileName, uid);
            if(!ownerId.equalsIgnoreCase("no")){
                for (UserInfo element : userInfoList) {
                    if(element.userId == Long.parseLong(ownerId) && element.connected){
                        element.userFile.receivedMessage(
                                "\n----------------------------NOTIFICATION----------------------------------------\n" + 
                                "A user with ID = "+ uid +" READ your file named "+ fileName +"." +       
                                "\n----------------------------NOTIFICATION----------------------------------------\n\n");
                        break;
                    }
                }
            }
            
            return content;
        }
        return null;
    }

    @Override
    public synchronized boolean writeFile(String fileName, String dataToWrite, long userId, String method) throws RemoteException {
        FileInfo fileInfo = new FileInfo();
        String uid = Long.toString(userId);
        boolean permission = filedao.writeToFileInDatabase(fileName, uid);
        if(permission){
            success = fileInfo.writeIntoFile(uid, uid, method);
            if(success){
                String ownerId = filedao.ownerNotification(fileName, uid);
                if(!ownerId.equalsIgnoreCase("no")){
                    for (UserInfo element : userInfoList) {
                        if(element.userId == Long.parseLong(ownerId) && element.connected){
                            element.userFile.receivedMessage(
                                    "\n----------------------------NOTIFICATION----------------------------------------\n" + 
                                    "A user with ID = "+ uid +" WROTE into your file named "+ fileName +"." +       
                                    "\n----------------------------NOTIFICATION----------------------------------------\n\n");
                            break;
                        }
                    }
                }
                return true;
            }
        }
        return false;
    }

    @Override
    public synchronized boolean notification(String fileName, long userId) throws RemoteException {
        
        String uid = Long.toString(userId);
        boolean done = filedao.notificationSetter(fileName, uid);
        return done;
    }

    @Override
    public synchronized String[] downloadFile(String fileName, long userId) throws RemoteException {
        FileInfo fileInfo = new FileInfo();
        String uid = Long.toString(userId);
        boolean permission = filedao.getFileFromDatabase(fileName, uid);
        if (permission){
            String[] content = fileInfo.downloadFile(uid);
            return content;
        }
        return null;
    }

    @Override
    public synchronized boolean uploadFile(String fileName, String[] content, long userId, boolean pubAccess, boolean rwPermission) throws RemoteException {
        try {
            FileInfo fileInfo = new FileInfo();
            double fileSize = (double) fileInfo.uploadFile(fileName, content);
            String uid = Long.toString(userId);
            success = filedao.fileFileDAO(fileName, fileSize, uid, pubAccess, rwPermission);
            
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(ServerController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return success;
    }
}
