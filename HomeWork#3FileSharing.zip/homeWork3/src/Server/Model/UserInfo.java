package Server.Model;

import Common.UserFile;

public class UserInfo {

    public long userId;
    private String username = null;   
    private String password = null;   
    public boolean connected =false;
    public UserFile userFile = null;

    public UserInfo(UserFile userFile ,String username, String password) {
        this.username = username;
        this.password = password;
        this.userFile = userFile;
        connected = false;
        userId =0;
    }
}
