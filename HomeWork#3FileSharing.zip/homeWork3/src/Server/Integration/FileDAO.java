
package Server.Integration;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;



public class FileDAO {
    
    private  Connection connection;
    private  Statement statement;
    private static final String TABLE_NAME= "fileTable";
    private PreparedStatement preparedStatement;
    
 
  

    public FileDAO() throws ClassNotFoundException, SQLException {   // I could use both method to make db in constrauctor but I wanted to have a short difference with course tranning
        this.connection = connection;                                 // I just left them as a comment
        this.statement = statement;
//        Class.forName("org.apache.derby.jdbc.ClientDriver");
//        connection = DriverManager.getConnection("jdbc:derby://localhost:1527/myDB", "jdbc","jdbc");
//        createTable(connection);
//        statement= connection.createStatement();
        
    }

      
    public boolean fileFileDAO  (String name,double size, String userId,boolean pubAccess, boolean rwPermission) throws ClassNotFoundException, SQLException {
        Class.forName("org.apache.derby.jdbc.ClientDriver");
        connection = DriverManager.getConnection("jdbc:derby://localhost:1527/myDB", "jdbc","jdbc");
        createTable(connection);
        statement= connection.createStatement();
      try{
          prepareStatements(connection);
          boolean notify = false;
          preparedStatement.setString(1,name);
          preparedStatement.setDouble(2,size);
          preparedStatement.setString(3, userId);
          preparedStatement.setBoolean(4, pubAccess);
          preparedStatement.setBoolean(5, rwPermission);
          preparedStatement.setBoolean(6, notify);
          preparedStatement.executeUpdate();
          return true;
      }catch (SQLException sql){
          System.out.println("hereeeee "+ sql.getSQLState());
      }
       return false;
    }
    
    public List<String> fileList(long uid){
        List<String> listOfFiles = new ArrayList<>();
        try {
            String fileAttributes;
            String id = Long.toString(uid);
            ResultSet resultSet = statement.executeQuery("SELECT * FROM " + TABLE_NAME + " WHERE owner ='"+id+"' OR public_access = 'TRUE'");
            while (resultSet.next()){
                fileAttributes = "Filename: " + resultSet.getString("name")+"    "+ "Filesize: " + resultSet.getDouble("size") 
                        +"    "+ "Owner ID: " +resultSet.getString("owner") +"    "+  "Write Permission: " + resultSet.getBoolean("rw_permission"); 
                listOfFiles.add(fileAttributes);
            }
            
        }  catch (SQLException ex) {
            Logger.getLogger(FileDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return listOfFiles;
        
    }
   
     private void createTable(Connection connection) throws SQLException {
        if (!tableExists(connection)) {
            Statement stmt = connection.createStatement();
            stmt.executeUpdate(
                    "create table " + TABLE_NAME + " (name varchar(32) primary key,size double, owner varchar(25), PUBLIC_ACCESS boolean, "
                            + "RW_PERMISSION boolean, NOTIFICATION boolean)");
        }
    }
    private boolean tableExists(Connection connection) throws SQLException {
        DatabaseMetaData metaData = connection.getMetaData();
        ResultSet tableMetaData = metaData.getTables(null, null, null, null);
        while (tableMetaData.next()) {
            String tableName = tableMetaData.getString(3);
            if (tableName.equalsIgnoreCase(TABLE_NAME)) {
                return true;
            }
        }
        return false;
    }
     public void prepareStatements(Connection connection) throws SQLException {
            preparedStatement = connection.prepareStatement("INSERT INTO " +TABLE_NAME+ " VALUES(?,?,?,?,?,?)");
    }
     
     public boolean notificationSetter(String fileName, String userId){
        try {
            ResultSet resultSet = statement.executeQuery("SELECT * FROM " +TABLE_NAME + " WHERE name ='"+fileName+"' AND"
                    + " owner ='"+userId+"' AND public_access = 'TRUE'" );
            
            if(resultSet.next()){
                statement.executeUpdate("UPDATE " + TABLE_NAME + 
                        " SET notification = 'TRUE' WHERE name ='"+fileName+"' AND owner ='"+userId+"'");
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(FileDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
   } 
     
      public String ownerNotification(String fileName, String userId){
       try {
            ResultSet resultSet = statement.executeQuery("SELECT * FROM " + TABLE_NAME + " WHERE (name ='"+fileName+"') AND"
                    + " (NOT owner ='"+userId+"') AND (notification = 'TRUE')" );
            
            if(resultSet.next()){
                return resultSet.getString("owner");
            }
        } catch (SQLException ex) {
            Logger.getLogger(FileDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "no";
   }
      
       public boolean getFileFromDatabase(String fileName, String userId){
       try {
            ResultSet resultSet = statement.executeQuery("SELECT * FROM " + TABLE_NAME + " WHERE (name ='"+fileName+"') AND (owner ='"+userId+"' OR public_access = 'TRUE')");
            if(resultSet.next()){
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(FileDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
   }
   
   public boolean deleteFileFromDatabase(String fileName, String userId){
       try {
            ResultSet resultSet = statement.executeQuery("SELECT * FROM " + TABLE_NAME + " WHERE (name ='"+fileName+"') AND (owner ='"+userId+"' "
                    + "OR (public_access = 'TRUE' AND RW_PERMISSION = 'TRUE'))");
            if(resultSet.next()){
                statement.executeUpdate("DELETE FROM " + TABLE_NAME + " WHERE name ='"+fileName+"' AND owner ='"+userId+"'");
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(FileDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
   }
    
   public boolean writeToFileInDatabase(String fileName,String  userId) {
       try {
            ResultSet resultSet = statement.executeQuery("SELECT * FROM " + TABLE_NAME + " WHERE (name ='"+fileName+"') AND"
                    + " ((owner ='"+userId+"') OR (public_access = 'TRUE' AND RW_PERMISSION = 'TRUE'))" );
            
            if(resultSet.next()){
                return true;
            }
        }catch (SQLException ex) {
            Logger.getLogger(FileDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
   }
      
}

