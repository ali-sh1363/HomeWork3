package Server.Stratup;

import Server.Controller.ServerController;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.sql.SQLException;


public class ServerStarter {

    public static void main (String[] args) throws ClassNotFoundException, SQLException{
        try {
            new ServerStarter().StartRegistry();
            Naming.rebind(ServerController.SERVER_NAME_IN_REGISTRY, new ServerController());
            System.out.println("Server is Running ");
        }catch (MalformedURLException | RemoteException rx){
            System.out.println("Server Starter !!!" +rx.getMessage());
        }
    }


    private void StartRegistry() throws RemoteException{
        try{
            LocateRegistry.getRegistry().list();
        }catch (RemoteException noRegistryIsRunning){
            LocateRegistry.createRegistry(Registry.REGISTRY_PORT);
        }
    }
}
